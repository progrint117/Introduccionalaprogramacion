#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float a,b,x,y;
	printf("De el valor de x\n");
	scanf("%f",&x);
	printf("De el valor de y\n");
	scanf("%f",&y);
	printf("De el valor de a\n");
	scanf("%f",&a);
	printf("De el valor de b\n");
	scanf("%f",&b);
	printf("El resultado (x+y)2 (a-b) es %.2f", (x+y)*(x+y)*(a-b));
	return 0;
}
