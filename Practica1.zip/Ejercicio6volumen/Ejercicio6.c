#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char l;
	float D,P, a, f, g, x, y, R, z, pi, va, vf;
	printf("De el liquido que es, A para agua y G para gasolina:\n");
	scanf("%c", &l);
	printf("De el diametro del cilindro en metros: \n");
	scanf("%f", &D);
	printf("De el valor de la presion hidrostatica: \n");
	scanf("%f", &P);
	a=1000;
	f=820;
	g=9.81;
	x= P/(a*g);
	y= P/(f*g);
	pi=3.1416;
	va=pi*((D/2)*(D/2))*x;
	vf=pi*((D/2)*(D/2))*y;
    R= (l=='A') ? printf("El volumen es: %f", va) : l=='G' ? printf("El volumen es: %f", vf) : z;
	
	
	return 0;
}
