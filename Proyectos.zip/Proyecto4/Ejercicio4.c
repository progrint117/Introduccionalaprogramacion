#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int totalsegundos, minutos, horas, segundos, m, n, o, p, q, r;

	printf("De el numero de segundos:\n");
	scanf("%d", &totalsegundos);
    m= ((totalsegundos/3600)>=1) ?horas :n;
	horas= totalsegundos/3600;
	o=((totalsegundos%3600)>=60) ?minutos :p;
	minutos= ((totalsegundos%3600)/60);
	q=((totalsegundos%60)>=60) ?segundos :r;
	segundos= totalsegundos%60;
	
    printf("Horas=%d \nMinutos=%d \nSegundos=%d ",horas, minutos, segundos);
    
	

	return 0;
}
