#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float pi, r, h, g, v, a;
	pi=3.1416;
	printf("De el valor de la altura del cono:\n");
	scanf("%f", &h);
	printf("De el valor del radio del cono:\n");
	scanf("%f", &r);
	g=(sqrt((h*h)+(r*r)));
	a=(2*pi*r*(g/2))+(pi*(r*r));
	v=(pi/3)*(r*r)*(h);
	printf("El volumen es %.2f \n", v);
	printf("El valor del area del cono es %.2f", a);
	
	return 0;
}
