#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float pies, pulgadas, yardas, centimetros, metro;

	
	
	printf("De el numero de pies: \n");
	scanf("%f", &pies);
	pulgadas= 12*pies;
	yardas= pies/3;
	printf("Pulgadas= %.2f \nYardas %.2f \n", pulgadas, yardas);
	centimetros= pulgadas*2.54;
	printf("Centimetros= %.2f \n", centimetros);
	metro= centimetros/100;
	printf("Metros= %.2f", metro);
	
	return 0;
}
