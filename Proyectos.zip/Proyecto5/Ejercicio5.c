#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float c, f, numerogrados, r;
	char g, G;
	printf("De el numero de grados y la unidad de los grados C para Centigrados y F para Farenheit\n");
	scanf("%f %c", &numerogrados,&g);
    f= ((9*numerogrados)/5)+32;
	c= ((numerogrados-32)*5)/9;
	G=(g=='C') ? printf("El numero de grados Farenheit es= %.1f", f): g=='F' ? printf("El numero de grados centigrados es= %.1f", c) :r;
	
	
	
    	

	
	return 0; 
}
